import java.util.Scanner;
import java.io.*;
import java.util.*;
/**
 * A model for the game of 20 questions
 *
 * @author Vidhi
 * @author Kathan
 * @author Arunima
 * @author Jonathan
 */


public class DecisionTree
{
	private class BTNode{
		String line;
		BTNode yes;
		BTNode no;

		public BTNode(String word) {
			this.line = word; 
			this.yes = null; 
			this.no = null;
		}

		public BTNode(String word, BTNode left, BTNode right) {
			this.line = word;
			this.yes = left;
			this.no = right;
		}

		@ Override
		public String toString() {
			return line + '\n';
		}
	}

	/**
	 * Constructor needed to create the game.
	 *
	 * @param fileName
	 *          this is the name of the file we need to import the game questions
	 *          and answers from.
	 */

	private BTNode overallRoot;
	private BTNode current;
	String fileName;
	Scanner console;
	public DecisionTree(String fileName) 
	{
		this.fileName = fileName;
		try {
		console = new Scanner(new File(fileName));
		this.overallRoot = build();
		this.current = this.overallRoot;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public BTNode build() throws IOException {
		String line = console.nextLine().trim();
		BTNode root = new BTNode(line);
		
		if(line.charAt(line.length() - 1) == '?') {
			root.yes = build();
			root.no = build();
		}
		
		return root;
	}


	/*
	 * Add a new question and answer to the currentNode. If the current node has
	 * the answer chicken, theGame.add("Does it swim?", "goose"); should change
	 * that node like this:
	 */
	// -----------Feathers?-----------------Feathers?------
	// -------------/----\------------------/-------\------
	// ------- chicken  horse-----Does it swim?-----horse--
	// -----------------------------/------\---------------
	// --------------------------goose--chicken-----------
	/**
	 * @param newQ
	 *          The question to add where the old answer was.
	 * @param newA
	 *          The new Yes answer for the new question.
	 */
	public void add(String newQ, String newA)
	{
		String temp = this.current.line;
		this.current.line = newQ;
		current.yes = new BTNode(newA);
		current.no = new BTNode(temp);
	}

	/**
	 * True if getCurrent() returns an answer rather than a question.
	 *
	 * @return False if the current node is an internal node rather than an answer
	 *         at a leaf.
	 */
	public boolean foundAnswer()
	{
		return (this.getCurrent().charAt(this.getCurrent().length() - 1) != '?');
	}

	/**
	 * Return the data for the current node, which could be a question or an
	 * answer.  Current will change based on the users progress through the game.
	 *
	 * @return The current question or answer.
	 */
	public String getCurrent()
	{
		return this.current.line;
	}

	/**
	 * Ask the game to update the current node by going left for Choice.yes or
	 * right for Choice.no Example code: theGame.playerSelected(Choice.Yes);
	 *
	 * @param yesOrNo
	 */
	public void playerSelected(Choice yesOrNo)
	{
		if(yesOrNo == Choice.Yes) {
			current = current.yes;
		}else {
			current = current.no;
		}
	}

	/**
	 * Begin a game at the root of the tree. getCurrent should return the question
	 * at the root of this GameTree.
	 */
	public void reStart()
	{
		this.current = this.overallRoot;
	}

	@Override
	public String toString()
	{
		return toStringHelper(this.overallRoot,1);
	}

	public String toStringHelper(BTNode root, int level) {
		String output = "" ;
		if(root == null) return "";
		//if(root.no == null && root.yes == null) output += dashes(level) + root.line;
		output += toStringHelper(root.no, level + 1) + 
				//toStringHelper(root, ++level) + 
				 dashes(level) + root.line + "\n" +
				toStringHelper(root.yes, level + 1);
		return output;
	}

	public String dashes(int level) {
		String output = "";
		for(int i = 0; i < level - 1; i++) {
			output += "- ";
		}
		return output;
	}

	/**
	 * Overwrite the old file for this gameTree with the current state that may
	 * have new questions added since the game started.
	 *
	 */
	public void saveGame()
	{
		String outputFileName = this.fileName;
		PrintWriter diskFile = null;
		try {
			diskFile = new PrintWriter(new File(outputFileName));
			}catch (IOException io) {
		System.out.println("Could not create file: " + outputFileName);}//diskFile hasthe familiar print and println methods of System.out//see the PrintWriter class' API for more info
		diskFile.print(this.saveHelper(this.overallRoot));
		diskFile.close();
	}
	
	public String saveHelper(BTNode root) {
		if(root == null) return "";
		return root.line + "\n" + saveHelper(root.yes) + saveHelper(root.no);
				//current data + call to left + call to right;
	}
	
	public static void main(String args[]) throws IOException {
		DecisionTree g = new DecisionTree("actors.txt");
		System.out.println(g.toString());
	}
}
